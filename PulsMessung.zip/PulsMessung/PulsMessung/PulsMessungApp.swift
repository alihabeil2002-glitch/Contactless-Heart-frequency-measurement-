//
//  PulsMessungApp.swift
//  PulsMessung
//
//  Created by Yassine on 14/10/2025.
//

//
//  PulsMessungApp.swift
//  PulsMessung
//
//  Created by its on 13.08.25.
//

import SwiftUI

@main
struct PulsMessungApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
