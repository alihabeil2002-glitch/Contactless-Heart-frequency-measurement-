import SwiftUI
import AVFoundation

struct ContentView: View {
    @StateObject private var camera = CameraManager()

    var body: some View {
        ZStack(alignment: .topLeading) {
            CameraPreview(session: camera.captureSession, faceRect: camera.faceRectMeta)
                .ignoresSafeArea()

            VStack(alignment: .leading, spacing: 10) {
                Text(bpmText(camera.bpm))
                    .font(.system(size: 44, weight: .bold, design: .rounded))
                    .padding(10)
                    .background(.ultraThinMaterial)
                    .cornerRadius(12)

                if let hud = camera.debugHUD, !hud.isEmpty {
                    Text(hud)
                        .font(.system(size: 14, weight: .semibold, design: .monospaced))
                        .padding(8)
                        .background(.ultraThinMaterial)
                        .cornerRadius(10)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
            .padding()
        }
        .navigationTitle("Kamera")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear { camera.checkPermissionAndConfigure() }
    }

    private func bpmText(_ v: Double?) -> String {
        guard let v else { return "BPM: —" }
        return "BPM: \(Int(v.rounded()))"
    }
}








