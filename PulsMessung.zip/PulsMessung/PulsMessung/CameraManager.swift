import Foundation
import AVFoundation
import Combine
import Vision
import CoreGraphics
import QuartzCore
import simd
#if canImport(UIKit)
import UIKit
#endif

// MARK: - Heart-rate stabilizer
final class HRStabilizer {
    private var history: [Double] = []
    private var ema: Double?
    private var lastOut: Double?
    private var lastT: Double?

    var minSNRdB: Double = 8.0
    var emaAlpha: Double = 0.25
    var maxSlewPerSec: Double = 8.0
    var medianWindow: Int = 9

    func reset() { history.removeAll(); ema = nil; lastOut = nil; lastT = nil }

    func update(raw: Double?, snrDB: Double?, now: Double) -> Double? {
        guard let r = raw, r.isFinite else { return lastOut }
        if let s = snrDB, s < minSNRdB { return lastOut }

        history.append(r)
        if history.count > medianWindow { history.removeFirst(history.count - medianWindow) }
        let med = median(history)

        if let e = ema { ema = e*(1.0-emaAlpha) + med*emaAlpha } else { ema = med }

        var out = ema!
        if let lo = lastOut, let lt = lastT {
            let dt = max(1e-3, now - lt)
            let maxStep = maxSlewPerSec * dt
            let diff = out - lo
            if diff >  maxStep { out = lo + maxStep }
            if diff < -maxStep { out = lo - maxStep }
        }
        lastOut = out
        lastT = now
        return out
    }

    private func median(_ a: [Double]) -> Double {
        let s = a.sorted()
        let n = s.count
        return (n % 2 == 1) ? s[n/2] : 0.5*(s[n/2 - 1] + s[n/2])
    }
}

final class CameraManager: NSObject, ObservableObject, AVCaptureVideoDataOutputSampleBufferDelegate {

    let previewLayer: AVCaptureVideoPreviewLayer
    var captureSession: AVCaptureSession { session }

    @Published var isReady = false
    @Published var bpm: Double?
    @Published var debugHUD: String?

    @Published var faceRectMeta: CGRect? = nil
    @Published var foreheadRectMeta: CGRect? = nil
    @Published var foreheadDetected: Bool = false

    private let session = AVCaptureSession()
    private let sessionQueue = DispatchQueue(label: "camera.session")
    private let videoOutputQueue = DispatchQueue(label: "camera.videoOutput", qos: .userInitiated)
    private let videoOutput = AVCaptureVideoDataOutput()
    private var captureDevice: AVCaptureDevice?

    private let rppg = RppgProcessorCHROM()
    private let hrSmooth = HRStabilizer()

    private var frameCounter = 0
    private var lastFaceRectPx: CGRect?
    private var lastForeheadPx: CGRect?
    private let roiSmoothAlpha: CGFloat = 0.35
    private var roiValidUntil: Double = 0
    private let roiGraceSec: Double = 30.0

    private var lastFrameWall: CFTimeInterval = CACurrentMediaTime()
    private var lastSampleWall: CFTimeInterval = CACurrentMediaTime()
    private var watchdogTimer: Timer?

    private var prevForeheadCenter: CGPoint?
    private var motionLP: Double = 0
    private var prevLuma: Double?
    private var lumaJumpLP: Double = 0
    private let lpAlpha: Double = 0.35
    private var isNoisyFrame: Bool = false

    private var lastDisplayUpdateTime: Double = 0.0
    private let displayUpdateInterval: Double = 1.0
    private let displayMinBPM = 60.0
    private let displayMaxBPM = 180.0

    private var sequenceHandler = VNSequenceRequestHandler()
    private var trackedObservation: VNDetectedObjectObservation?
    private let rectanglesRequest = VNDetectFaceRectanglesRequest()
    private let refreshEveryNFrames = 1

    override init() {
        previewLayer = AVCaptureVideoPreviewLayer(session: session)
        super.init()
        previewLayer.videoGravity = .resizeAspectFill
        #if canImport(UIKit)
        previewLayer.contentsScale = UIScreen.main.scale
        #endif
        startWatchdog()
    }

    deinit { watchdogTimer?.invalidate() }

    private func startWatchdog() {
        DispatchQueue.main.async {
            self.watchdogTimer?.invalidate()
            self.watchdogTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
                guard let self else { return }
                let now = CACurrentMediaTime()
                if now - self.lastFrameWall > 8.0 || now - self.lastSampleWall > 6.0 {
                    self.trackedObservation = nil
                    if !self.session.isRunning {
                        self.sessionQueue.async { [weak self] in self?.session.startRunning() }
                    }
                    self.lastFrameWall = now
                    self.lastSampleWall = now
                }
            }
        }
    }

    // MARK: Permissions + session
    func checkPermissionAndConfigure() {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized: configureSession()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                guard let self else { return }
                DispatchQueue.main.async { if granted { self.configureSession() } }
            }
        case .denied, .restricted:
            DispatchQueue.main.async { print("Camera permission denied or restricted") }
        @unknown default: break
        }
    }

    private func configureSession() {
        sessionQueue.async {
            self.session.beginConfiguration()
            self.session.sessionPreset = .inputPriority

            guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front) else {
                self.session.commitConfiguration(); return
            }
            self.captureDevice = device

            do {
                let input = try AVCaptureDeviceInput(device: device)
                guard self.session.canAddInput(input) else {
                    self.session.commitConfiguration(); return
                }
                self.session.addInput(input)
            } catch {
                self.session.commitConfiguration(); return
            }

            self.selectBest60fpsFormat720pOrLower(for: device)

            self.videoOutput.alwaysDiscardsLateVideoFrames = true
            self.videoOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]
            if self.session.canAddOutput(self.videoOutput) {
                self.session.addOutput(self.videoOutput)
                self.videoOutput.setSampleBufferDelegate(self, queue: self.videoOutputQueue)
                if let conn = self.videoOutput.connection(with: .video) {
                    if #available(iOS 17.0, *) {
                        if conn.isVideoRotationAngleSupported(90) { conn.videoRotationAngle = 90 }
                        else if conn.isVideoRotationAngleSupported(0) { conn.videoRotationAngle = 0 }
                    } else {
                        conn.videoOrientation = .portrait
                    }
                    if conn.isVideoMirroringSupported { conn.isVideoMirrored = true }
                    if conn.isVideoStabilizationSupported { conn.preferredVideoStabilizationMode = .standard }
                }
            }

            self.session.commitConfiguration()
            DispatchQueue.main.async { self.isReady = true }
            if !self.session.isRunning { self.session.startRunning() }

            self.settleThenLockCameraControls()
        }
    }

    private func settleThenLockCameraControls() {
        sessionQueue.asyncAfter(deadline: .now() + 0.6) { [weak self] in
            guard let self, let device = self.captureDevice else { return }
            do {
                try device.lockForConfiguration()
                if device.isFocusModeSupported(.continuousAutoFocus) { device.focusMode = .continuousAutoFocus }
                if device.isExposureModeSupported(.continuousAutoExposure) { device.exposureMode = .continuousAutoExposure }
                if device.isWhiteBalanceModeSupported(.continuousAutoWhiteBalance) { device.whiteBalanceMode = .continuousAutoWhiteBalance }
                device.unlockForConfiguration()
            } catch {}
        }
        sessionQueue.asyncAfter(deadline: .now() + 2.0) { [weak self] in
            guard let self, let device = self.captureDevice else { return }
            do {
                try device.lockForConfiguration()
                if device.isFocusModeSupported(.locked) { device.focusMode = .locked }
                if device.isExposureModeSupported(.locked) { device.exposureMode = .locked }
                if device.isWhiteBalanceModeSupported(.locked) { device.whiteBalanceMode = .locked }
                device.isSubjectAreaChangeMonitoringEnabled = false
                device.unlockForConfiguration()
            } catch {}
        }
    }

    // MARK: Capture output
    func captureOutput(_ output: AVCaptureOutput,
                       didOutput sampleBuffer: CMSampleBuffer,
                       from connection: AVCaptureConnection) {

        autoreleasepool {
            guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
            let tNow = CMTimeGetSeconds(CMSampleBufferGetPresentationTimeStamp(sampleBuffer))
            if rppg.firstSampleTime == nil { rppg.firstSampleTime = tNow }
            lastFrameWall = CACurrentMediaTime()
            let visionOrientation: CGImagePropertyOrientation = connection.isVideoMirrored ? .leftMirrored : .right
            frameCounter &+= 1

            // ---- Face tracking ----
            var facePx: CGRect? = nil
            if let tracked = trackedObservation {
                let request = VNTrackObjectRequest(detectedObjectObservation: tracked)
                request.trackingLevel = .accurate
                do {
                    try sequenceHandler.perform([request], on: pixelBuffer, orientation: visionOrientation)
                    if let obs = request.results?.first as? VNDetectedObjectObservation, obs.confidence > 0.35 {
                        trackedObservation = obs
                        let w = CGFloat(CVPixelBufferGetWidth(pixelBuffer))
                        let h = CGFloat(CVPixelBufferGetHeight(pixelBuffer))
                        let r = obs.boundingBox
                        facePx = CGRect(x: r.minX * w,
                                        y: (1.0 - r.maxY) * h,
                                        width: r.width * w,
                                        height: r.height * h)
                    } else { trackedObservation = nil }
                } catch { trackedObservation = nil }
            }

            if facePx == nil || frameCounter % refreshEveryNFrames == 0 {
                do {
                    try VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: visionOrientation, options: [:])
                        .perform([rectanglesRequest])
                } catch {}

                if let obs = (rectanglesRequest.results)?.first {
                    let faceMeta = visionRectToNormalizedTopLeft(obs.boundingBox)
                    let facePxNew = visionRectToPixelRect(obs.boundingBox, in: pixelBuffer)
                    let fh = foreheadBandMatchingVideo(from: facePxNew)

                    facePx = facePxNew
                    lastFaceRectPx = facePxNew
                    lastForeheadPx = fh
                    roiValidUntil = tNow + roiGraceSec

                    // lock exposure to ROI
                    self.lockExposure(to: fh, in: pixelBuffer)

                    let vnRect = CGRect(x: faceMeta.minX, y: 1.0 - faceMeta.maxY, width: faceMeta.width, height: faceMeta.height)
                    trackedObservation = VNDetectedObjectObservation(boundingBox: vnRect)

                    DispatchQueue.main.async {
                        self.faceRectMeta = faceMeta
                        self.foreheadRectMeta = nil
                        self.foreheadDetected = true
                    }
                } else if tNow > roiValidUntil {
                    lastFaceRectPx = nil
                    lastForeheadPx = nil
                    trackedObservation = nil
                    hrSmooth.reset()
                    DispatchQueue.main.async {
                        self.faceRectMeta = nil
                        self.foreheadRectMeta = nil
                        self.foreheadDetected = false
                    }
                }
            } else if let fpx = facePx {
                let fh = foreheadBandMatchingVideo(from: fpx)
                let smoothed = smoothRect(prev: lastForeheadPx, next: fh, alpha: roiSmoothAlpha)
                lastFaceRectPx = fpx
                lastForeheadPx = smoothed
                roiValidUntil = tNow + roiGraceSec

                // update exposure lock as ROI drifts
                self.lockExposure(to: smoothed, in: pixelBuffer)

                let meta = pixelRectToNormalizedTopLeft(fpx, in: pixelBuffer)
                DispatchQueue.main.async {
                    self.faceRectMeta = meta
                    self.foreheadRectMeta = nil
                    self.foreheadDetected = true
                }
            }

            // ---- Forehead sampling + quality metrics ----
            if let fpx = lastFaceRectPx {
                let roiF = lastForeheadPx ?? foreheadBandMatchingVideo(from: fpx)

                let c = CGPoint(x: roiF.midX, y: roiF.midY)
                if let p = prevForeheadCenter {
                    let dx = Double(c.x - p.x), dy = Double(c.y - p.y)
                    let dist = sqrt(dx*dx + dy*dy)
                    let diag = hypot(fpx.width, fpx.height)
                    let step = diag > 0 ? dist / Double(diag) : 0
                    motionLP = motionLP * (1 - lpAlpha) + step * lpAlpha
                }
                prevForeheadCenter = c

                if let rgb = skinMaskedMeanRGB_BGRA_Strict(in: pixelBuffer, roi: roiF, subsample: 2) {
                    let luma = 0.299*Double(rgb.x) + 0.587*Double(rgb.y) + 0.114*Double(rgb.z)
                    if let pl = prevLuma {
                        let jump = abs(luma - pl) / max(pl, 1e-6)
                        lumaJumpLP = lumaJumpLP * (1 - lpAlpha) + jump * lpAlpha
                    }
                    prevLuma = luma

                    isNoisyFrame = (motionLP > 0.012 || lumaJumpLP > 0.06)

                    if !isNoisyFrame {
                        rppg.appendSample(t: tNow, r: Double(rgb.x), g: Double(rgb.y), b: Double(rgb.z))
                        lastSampleWall = CACurrentMediaTime()
                    }
                    DispatchQueue.main.async { self.pushDisplay(now: tNow) }
                } else {
                    DispatchQueue.main.async { self.pushDisplay(now: tNow) }
                }
            } else {
                DispatchQueue.main.async { self.pushDisplay(now: tNow) }
            }
        }
    }

    private func pushDisplay(now: Double) {
        guard now - lastDisplayUpdateTime >= displayUpdateInterval else { return }
        lastDisplayUpdateTime = now

        let (hrRaw, snr, method) = rppg.estimateBPM()
        let hrStable = hrSmooth.update(raw: hrRaw, snrDB: snr, now: now)

        let gateTxt = isNoisyFrame ? "noisy" : "ok"
        if let h = hrStable {
            bpm = min(max(h, displayMinBPM), displayMaxBPM)
            let snrTxt = snr.map { String(format: "%.1f", $0) } ?? "—"
            debugHUD = "CHROM | SNR \(snrTxt) dB | \(method) | \(gateTxt)"
        } else {
            let snrTxt = snr.map { String(format: "%.1f", $0) } ?? "—"
            debugHUD = "CHROM | collecting | SNR \(snrTxt) dB | \(gateTxt)"
        }
    }

    // MARK: ROI helpers
    private func smoothRect(prev: CGRect?, next: CGRect, alpha a: CGFloat) -> CGRect {
        guard let p = prev else { return next.integral }
        let oneMinusA: CGFloat = 1.0 - a
        let x = p.origin.x   * oneMinusA + next.origin.x    * a
        let y = p.origin.y   * oneMinusA + next.origin.y    * a
        let w = p.size.width  * oneMinusA + next.size.width  * a
        let h = p.size.height * oneMinusA + next.size.height * a
        return CGRect(x: x, y: y, width: w, height: h).integral
    }

    private func foreheadBandMatchingVideo(from face: CGRect) -> CGRect {
        let x0 = face.minX + 0.32 * face.width
        let x1 = face.minX + 0.68 * face.width
        let y0 = face.minY + 0.18 * face.height
        let y1 = face.minY + 0.30 * face.height
        var r = CGRect(x: x0, y: y0, width: x1 - x0, height: y1 - y0).integral
        let inset = max(face.width, face.height) * 0.02
        let safe = face.insetBy(dx: inset, dy: inset)
        r = r.intersection(safe)
        return r
    }

    private func visionRectToNormalizedTopLeft(_ r: CGRect) -> CGRect {
        CGRect(x: r.origin.x, y: 1.0 - r.origin.y - r.height, width: r.width, height: r.height)
    }
    private func visionRectToPixelRect(_ r: CGRect, in pb: CVPixelBuffer) -> CGRect {
        let w = CGFloat(CVPixelBufferGetWidth(pb)), h = CGFloat(CVPixelBufferGetHeight(pb))
        return CGRect(x: r.origin.x * w,
                      y: (1.0 - r.origin.y - r.size.height) * h,
                      width: r.size.width * w,
                      height: r.size.height * h)
    }
    private func pixelRectToNormalizedTopLeft(_ r: CGRect, in pb: CVPixelBuffer) -> CGRect {
        let w = CGFloat(CVPixelBufferGetWidth(pb)), h = CGFloat(CVPixelBufferGetHeight(pb))
        return CGRect(x: r.minX / w, y: r.minY / h, width: r.width / w, height: r.height / h)
    }

    // Strict skin-masked mean RGB with stronger sample requirement
    private func skinMaskedMeanRGB_BGRA_Strict(in pb: CVPixelBuffer, roi: CGRect, subsample: Int = 2) -> SIMD3<Float>? {
        var roiI = roi.integral
        if roiI.width < 4 || roiI.height < 4 { return nil }

        CVPixelBufferLockBaseAddress(pb, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(pb, .readOnly) }

        guard let base = CVPixelBufferGetBaseAddress(pb) else { return nil }
        let bytesPerRow = CVPixelBufferGetBytesPerRow(pb)
        let w = CVPixelBufferGetWidth(pb)
        let h = CVPixelBufferGetHeight(pb)

        let x0 = max(0, min(Int(roiI.minX), w - 1))
        let y0 = max(0, min(Int(roiI.minY), h - 1))
        let x1 = max(0, min(Int(roiI.maxX), w))
        let y1 = max(0, min(Int(roiI.maxY), h))

        var rs: Double = 0, gs: Double = 0, bs: Double = 0, c: Double = 0
        let step = max(1, subsample)
        var rowPtr = base.advanced(by: y0 * bytesPerRow)
        for _ in stride(from: y0, to: y1, by: step) {
            let px = rowPtr.assumingMemoryBound(to: UInt8.self)
            for x in stride(from: x0, to: x1, by: step) {
                let off = x * 4 // BGRA
                let b = px[off + 0]
                let g = px[off + 1]
                let r = px[off + 2]

                if r < 8 || g < 8 || b < 8 { continue }
                if r > 246 || g > 246 || b > 246 { continue }

                let Y  =  0.299*Double(r) + 0.587*Double(g) + 0.114*Double(b)
                let Cb = -0.169*Double(r) - 0.331*Double(g) + 0.5*Double(b) + 128
                let Cr =  0.5*Double(r)   - 0.419*Double(g) - 0.081*Double(b) + 128
                if !((Cr > 133 && Cr < 178) && (Cb > 95 && Cb < 140) && (Y > 35 && Y < 220)) { continue }

                rs += Double(r); gs += Double(g); bs += Double(b); c += 1.0
            }
            rowPtr = rowPtr.advanced(by: step * bytesPerRow)
        }
        if c < 160 { return nil }
        return SIMD3<Float>(Float(rs/(255.0*c)), Float(gs/(255.0*c)), Float(bs/(255.0*c)))
    }

    private func selectBest60fpsFormat720pOrLower(for device: AVCaptureDevice) {
        var best: AVCaptureDevice.Format?
        var bestArea = 0
        for f in device.formats {
            guard let r = f.videoSupportedFrameRateRanges.first, r.maxFrameRate >= 60 else { continue }
            let d = CMVideoFormatDescriptionGetDimensions(f.formatDescription)
            guard d.width <= 1280 && d.height <= 720 else { continue }
            let area = Int(d.width) * Int(d.height)
            if area > bestArea { bestArea = area; best = f }
        }
        guard let fmt = best else { return }
        do {
            try device.lockForConfiguration()
            device.activeFormat = fmt
            device.activeVideoMinFrameDuration = CMTime(value: 1, timescale: 60)
            device.activeVideoMaxFrameDuration = CMTime(value: 1, timescale: 60)
            device.unlockForConfiguration()
        } catch { print("[CameraManager] Format selection failed: \(error)") }
    }

    // MARK: ROI-locked exposure with proper bias API
    private func lockExposure(to roiPx: CGRect, in pb: CVPixelBuffer) {
        guard let device = captureDevice else { return }
        let w = CGFloat(CVPixelBufferGetWidth(pb)), h = CGFloat(CVPixelBufferGetHeight(pb))
        let cx = max(0, min(1, roiPx.midX / w))
        let cy = max(0, min(1, roiPx.midY / h))
        sessionQueue.async { [weak self] in
            guard let self else { return }
            do {
                try device.lockForConfiguration()
                if device.isExposurePointOfInterestSupported {
                    device.exposurePointOfInterest = CGPoint(x: cx, y: cy)
                    if device.isExposureModeSupported(.continuousAutoExposure) {
                        device.exposureMode = .continuousAutoExposure
                    }
                }
                device.unlockForConfiguration()
                self.sessionQueue.asyncAfter(deadline: .now() + 0.5) {
                    do {
                        try device.lockForConfiguration()
                        if device.isExposureModeSupported(.locked) { device.exposureMode = .locked }
                        // use min/maxExposureTargetBias, not a non-existent flag
                        let targetBias: Float = -0.3
                        let clamped = max(device.minExposureTargetBias, min(device.maxExposureTargetBias, targetBias))
                        device.setExposureTargetBias(clamped, completionHandler: nil)
                        if device.isWhiteBalanceModeSupported(.locked) { device.whiteBalanceMode = .locked }
                        device.isSubjectAreaChangeMonitoringEnabled = false
                        device.unlockForConfiguration()
                    } catch {}
                }
            } catch {}
        }
    }
} 


