import Foundation

/// Hybrid POS + CHROM with continuity and harmonic vetting.
final class RppgProcessorCHROM {

    private(set) var lastBpm: Double?
    private(set) var lastSNR: Double?
    private(set) var lastMethod: String = "hybrid"

    private var tBuf: [Double] = []
    private var rBuf: [Double] = []
    private var gBuf: [Double] = []
    private var bBuf: [Double] = []

    private let lock = NSLock()

    // shorter windows for faster rise
    private let winShortSec: Double = 5.5
    private let winLongSec:  Double = 9.0

    // search band
    private let fMinHz = 42.0 / 60.0
    private let fMaxHz = 180.0 / 60.0
    private let bins: Int = 256

    // bandpass 0.7–3.0 Hz
    private var hp: Biquad = .init()
    private var lp: Biquad = .init()
    private var fsCache: Double = 0

    // POS detrend window
    private var maWinSec: Double = 1.0

    // continuity prior
    private let localBandBpm: Double = 30.0

    var firstSampleTime: Double?

    // MARK: Append
    func appendSample(t: Double, r: Double, g: Double, b: Double) {
        lock.lock()
        tBuf.append(t); rBuf.append(r); gBuf.append(g); bBuf.append(b)
        prune(olderThan: t - 20.0)
        lock.unlock()
    }

    // MARK: Estimate
    func estimateBPM() -> (Double?, Double?, String) {
        lock.lock(); defer { lock.unlock() }
        guard tBuf.count >= 60 else { return (nil, nil, "collecting") }

        let tNow = tBuf.last!
        let dtMed = medianDt()
        let fs = (dtMed > 0) ? (1.0 / dtMed) : 60.0
        ensureBandpass(fs: fs)

        let longR = sliceByTime(from: tNow - winLongSec, to: tNow)
        let shortR = sliceByTime(from: tNow - winShortSec, to: tNow)
        guard let rangeUse = longR ?? shortR else { return (nil, nil, "collecting") }

        let chrom = analyzeCHROM(range: rangeUse, fs: fs)
        let pos   = analyzePOS(range: rangeUse, fs: fs)
        let cont  = (lastBpm != nil) ? refineAroundLast(range: rangeUse, fs: fs, guess: lastBpm!) : nil

        let cands = [chrom, pos, cont].compactMap { $0 }
        guard !cands.isEmpty else { return (lastBpm, lastSNR, "hybrid/hold") }
        let best = pickBest(cands: cands, last: lastBpm)

        lastBpm = best.bpm
        lastSNR = best.snrDB
        lastMethod = best.method
        return (lastBpm, lastSNR, lastMethod)
    }

    // MARK: CHROM
    private func analyzeCHROM(range rIn: Range<Int>, fs: Double) -> (bpm: Double, snrDB: Double, method: String)? {
        guard let r = clamp(rIn) else { return nil }
        let n = r.count; if n < 60 { return nil }

        let mr = mean(of: rBuf, r), mg = mean(of: gBuf, r), mb = mean(of: bBuf, r)
        if mr <= 1e-9 || mg <= 1e-9 || mb <= 1e-9 { return nil }

        var X = [Double](repeating: 0, count: n)
        var Y = [Double](repeating: 0, count: n)
        for i in 0..<n {
            let k = r.lowerBound + i
            let R = rBuf[k] / mr - 1.0
            let G = gBuf[k] / mg - 1.0
            let B = bBuf[k] / mb - 1.0
            X[i] = 3.0*R - 2.0*G
            Y[i] = 1.5*R + 1.0*G - 1.5*B
        }
        let alpha = safeDiv(stddev(X), stddev(Y), fallback: 1.0)

        var S = [Double](repeating: 0, count: n)
        for i in 0..<n { S[i] = X[i] - alpha * Y[i] }

        var y = [Double](repeating: 0, count: n)
        var hp1 = hp, lp1 = lp
        for i in 0..<n { y[i] = lp1.process(hp1.process(S[i])) }

        return vettedPeak(y: y, fs: fs, tag: "CHROM")
    }

    // MARK: POS
    private func analyzePOS(range rIn: Range<Int>, fs: Double) -> (bpm: Double, snrDB: Double, method: String)? {
        guard let r = clamp(rIn) else { return nil }
        let n = r.count; if n < 60 { return nil }

        let mr = mean(of: rBuf, r), mg = mean(of: gBuf, r), mb = mean(of: bBuf, r)
        if mr <= 1e-9 || mg <= 1e-9 || mb <= 1e-9 { return nil }

        var R = [Double](repeating: 0, count: n)
        var G = [Double](repeating: 0, count: n)
        var B = [Double](repeating: 0, count: n)
        for i in 0..<n {
            let k = r.lowerBound + i
            R[i] = rBuf[k] / mr - 1.0
            G[i] = gBuf[k] / mg - 1.0
            B[i] = bBuf[k] / mb - 1.0
        }

        let win = max(3, Int(maWinSec * fs))
        let Rd = detrendMA(R, win)
        let Gd = detrendMA(G, win)
        let Bd = detrendMA(B, win)

        let ratio = safeDiv(stddev(Rd), stddev(Gd), fallback: 1.0)
        var S = [Double](repeating: 0, count: n)
        for i in 0..<n { S[i] = Gd[i] + ratio*Rd[i] - (1.0 + ratio)*Bd[i] }

        var y = [Double](repeating: 0, count: n)
        var hp1 = hp, lp1 = lp
        for i in 0..<n { y[i] = lp1.process(hp1.process(S[i])) }

        return vettedPeak(y: y, fs: fs, tag: "POS")
    }

    // MARK: Continuity refine
    private func refineAroundLast(range rIn: Range<Int>, fs: Double, guess: Double) -> (bpm: Double, snrDB: Double, method: String)? {
        guard let r = clamp(rIn) else { return nil }
        let n = r.count; if n < 60 { return nil }

        let mr = mean(of: rBuf, r), mg = mean(of: gBuf, r), mb = mean(of: bBuf, r)
        if mr <= 1e-9 || mg <= 1e-9 || mb <= 1e-9 { return nil }

        var X = [Double](repeating: 0, count: n)
        var Y = [Double](repeating: 0, count: n)
        for i in 0..<n {
            let k = r.lowerBound + i
            let R = rBuf[k] / mr - 1.0
            let G = gBuf[k] / mg - 1.0
            let B = bBuf[k] / mb - 1.0
            X[i] = 3.0*R - 2.0*G
            Y[i] = 1.5*R + 1.0*G - 1.5*B
        }
        let alpha = safeDiv(stddev(X), stddev(Y), fallback: 1.0)
        var S = [Double](repeating: 0, count: n)
        for i in 0..<n { S[i] = X[i] - alpha * Y[i] }
        var y = [Double](repeating: 0, count: n)
        var hp1 = hp, lp1 = lp
        for i in 0..<n { y[i] = lp1.process(hp1.process(S[i])) }

        return vettedPeak(y: y, fs: fs, tag: "CHROM/local", centerBpm: guess, spanBpm: localBandBpm)
    }

    // MARK: Peak + vetting
    private func vettedPeak(y: [Double], fs: Double, tag: String, centerBpm: Double? = nil, spanBpm: Double? = nil)
        -> (bpm: Double, snrDB: Double, method: String)? {

        let n = y.count
        if n < 16 { return nil }

        var tmp = y
        let m = tmp.reduce(0,+) / Double(n)
        for i in 0..<n { tmp[i] = (tmp[i] - m) * (0.54 - 0.46 * cos(2.0 * .pi * Double(i) / Double(n - 1))) }

        var f0 = fMinHz, f1 = fMaxHz
        if let c = centerBpm, let s = spanBpm {
            let ch = c/60.0, sh = s/60.0
            f0 = max(fMinHz, ch - sh)
            f1 = min(fMaxHz, ch + sh)
        }
        if f1 <= f0 { return nil }

        let N = bins
        var freqs = [Double](repeating: 0, count: N)
        var powers = [Double](repeating: 0, count: N)
        for k in 0..<N { freqs[k] = f0 + (f1 - f0) * Double(k) / Double(N - 1) }

        for k in 0..<N {
            let f = freqs[k]
            var re = 0.0, im = 0.0
            var phi = 0.0, dphi = 2.0 * .pi * f / fs
            for i in 0..<n {
                let s = tmp[i]
                re += s * cos(phi)
                im -= s * sin(phi)
                phi += dphi
            }
            powers[k] = re*re + im*im
        }

        var k0 = 1; var pBest = powers[1]
        for k in 2..<(N-1) { if powers[k] > pBest { pBest = powers[k]; k0 = k } }
        let pL = powers[k0-1], pC = powers[k0], pR = powers[k0+1]
        let denom = (pL - 2*pC + pR)
        let delta = (denom != 0) ? 0.5 * (pL - pR) / denom : 0.0
        let df = (f1 - f0) / Double(N - 1)
        let fBest = freqs[k0] + delta * df
        let bpmGuess = 60.0 * fBest

        let fundamental = harmonicRefine(freqs: freqs, powers: powers, fGuess: fBest)
        let guardHz = 0.10, bandHz = 0.06
        let snrDB = snrAround(freqs: freqs, powers: powers, fSignal: fundamental, bandHz: bandHz, guardHz: guardHz)

        return (60.0 * fundamental, snrDB, "hybrid/\(tag) g\(Int(bpmGuess.rounded()))")
    }

    private func harmonicRefine(freqs: [Double], powers: [Double], fGuess: Double) -> Double {
        func powerNear(_ f: Double, tol: Double = 0.05) -> Double {
            var acc = 0.0; var n = 0.0
            for i in 0..<freqs.count {
                if abs(freqs[i] - f) <= tol { acc += powers[i]; n += 1 }
            }
            return (n > 0) ? acc/n : 0.0
        }
        let p1 = powerNear(fGuess)
        let pHalf = powerNear(max(fMinHz, fGuess * 0.5))
        let pDouble = powerNear(min(fMaxHz, fGuess * 2.0))
        if pHalf > p1 * 1.25 { return max(fMinHz, fGuess * 0.5) }
        if pDouble > p1 * 1.25 { return min(fMaxHz, fGuess * 2.0) }
        return fGuess
    }

    private func snrAround(freqs: [Double], powers: [Double], fSignal: Double, bandHz: Double, guardHz: Double) -> Double {
        var sig = 0.0, sN = 0.0, noise = 0.0, nN = 0.0
        for k in 0..<freqs.count {
            let dfk = abs(freqs[k] - fSignal)
            if dfk <= bandHz { sig += powers[k]; sN += 1 }
            else if dfk >= guardHz { noise += powers[k]; nN += 1 }
        }
        sig = max(sig / max(sN, 1.0), 1e-12)
        noise = max(noise / max(nN, 1.0), 1e-12)
        return 10.0 * log10(sig / noise)
    }

    // pickBest with SNR and continuity bias
    private func pickBest(
        cands: [(bpm: Double, snrDB: Double, method: String)],
        last: Double?
    ) -> (bpm: Double, snrDB: Double, method: String) {

        func score(_ c: (bpm: Double, snrDB: Double, method: String)) -> Double {
            let snr = c.snrDB
            let cont = last.map { abs(c.bpm - $0) / 30.0 } ?? 0.0
            let bonus = c.method.contains("local") ? 0.25 : 0.0
            return snr - cont + bonus
        }

        let best = cands.max { score($0) < score($1) }!
        if let l = last {
            let near = cands.min { abs($0.bpm - l) < abs($1.bpm - l) }!
            if score(near) + 0.3 >= score(best) { return near }
        }
        return best
    }

    // MARK: Utils
    private func prune(olderThan tCut: Double) {
        guard let firstT = tBuf.first, firstT < tCut else { return }
        var idx = 0
        while idx < tBuf.count && tBuf[idx] < tCut { idx += 1 }
        let rm = min(idx, tBuf.count, rBuf.count, gBuf.count, bBuf.count)
        if rm > 0 {
            tBuf.removeFirst(rm)
            rBuf.removeFirst(rm)
            gBuf.removeFirst(rm)
            bBuf.removeFirst(rm)
        }
    }

    private func sliceByTime(from t0: Double, to t1: Double) -> Range<Int>? {
        guard !tBuf.isEmpty else { return nil }
        var i0 = 0
        while i0 < tBuf.count && tBuf[i0] < t0 { i0 += 1 }
        var i1 = i0
        while i1 < tBuf.count && tBuf[i1] <= t1 { i1 += 1 }
        return (i0 < i1) ? (i0..<i1) : nil
    }

    private func medianDt() -> Double {
        let n = tBuf.count
        if n < 3 { return 1.0/60.0 }
        let take = min(120, n - 1)
        var dts = [Double](repeating: 0, count: take)
        let start = n - take - 1
        for i in 0..<take { dts[i] = tBuf[start + i + 1] - tBuf[start + i] }
        dts.sort()
        let m = dts.count
        return (m % 2 == 1) ? dts[m/2] : 0.5*(dts[m/2 - 1] + dts[m/2])
    }

    private func clamp(_ r: Range<Int>) -> Range<Int>? {
        let n = min(rBuf.count, gBuf.count, bBuf.count, tBuf.count)
        let lo = max(0, min(r.lowerBound, n))
        let hi = max(lo, min(r.upperBound, n))
        return (hi > lo) ? (lo..<hi) : nil
    }

    private func mean(of a: [Double], _ r: Range<Int>) -> Double {
        let lo = max(0, min(r.lowerBound, a.count))
        let hi = max(lo, min(r.upperBound, a.count))
        if hi <= lo { return 0 }
        var s = 0.0
        for i in lo..<hi { s += a[i] }
        return s / Double(hi - lo)
    }

    private func stddev(_ x: [Double]) -> Double {
        if x.isEmpty { return 0 }
        let m = x.reduce(0,+) / Double(x.count)
        var s = 0.0
        for v in x { s += (v - m) * (v - m) }
        s /= Double(max(1, x.count - 1))
        return sqrt(s)
    }

    private func detrendMA(_ x: [Double], _ win: Int) -> [Double] {
        let n = x.count; if n == 0 { return [] }
        let w = max(3, min(win, n))
        var out = [Double](repeating: 0, count: n)
        var sum = 0.0
        var q: [Double] = []
        q.reserveCapacity(w)
        for i in 0..<n {
            sum += x[i]; q.append(x[i])
            if q.count > w { sum -= q.removeFirst() }
            let mean = sum / Double(q.count)
            out[i] = x[i] - mean
        }
        return out
    }

    private func safeDiv(_ a: Double, _ b: Double, fallback: Double) -> Double {
        return (abs(b) > 1e-12) ? (a / b) : fallback
    }

    // biquad
    private struct Biquad { var b0:Double=0,b1:Double=0,b2:Double=0,a1:Double=0,a2:Double=0,z1:Double=0,z2:Double=0
        mutating func process(_ x: Double) -> Double { let y=b0*x+z1; z1=b1*x - a1*y + z2; z2=b2*x - a2*y; return y } }
    private func hpDesign(fs: Double, cut: Double, q: Double = 0.707) -> Biquad {
        let nyq = 0.5*fs; var fc = cut/nyq; fc = max(0.01, min(fc, 0.99))
        let w = 2.0 * .pi * fc, sw = sin(w), cw = cos(w)
        let a = sw/(2.0*q)
        let b0 = (1 + cw)/2, b1 = -(1 + cw), b2 = (1 + cw)/2
        let a0 = 1 + a, a1 = -2*cw, a2 = 1 - a
        return Biquad(b0:b0/a0,b1:b1/a0,b2:b2/a0,a1:a1/a0,a2:a2/a0)
    }
    private func lpDesign(fs: Double, cut: Double, q: Double = 0.707) -> Biquad {
        let nyq = 0.5*fs; var fc = cut/nyq; fc = max(0.01, min(fc, 0.99))
        let w = 2.0 * .pi * fc, sw = sin(w), cw = cos(w)
        let a = sw/(2.0*q)
        let b0 = (1 - cw)/2, b1 = 1 - cw, b2 = (1 - cw)/2
        let a0 = 1 + a, a1 = -2*cw, a2 = 1 - a
        return Biquad(b0:b0/a0,b1:b1/a0,b2:b2/a0,a1:a1/a0,a2:a2/a0)
    }
    private func ensureBandpass(fs: Double) {
        if abs(fs - fsCache) < 1e-6 { return }
        fsCache = fs
        hp = hpDesign(fs: fs, cut: 0.7)
        lp = lpDesign(fs: fs, cut: 3.0)
    }
}

