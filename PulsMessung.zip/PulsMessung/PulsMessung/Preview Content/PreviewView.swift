import SwiftUI
import UIKit
import AVFoundation

final class PreviewView: UIView {
    override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }
    var videoPreviewLayer: AVCaptureVideoPreviewLayer { layer as! AVCaptureVideoPreviewLayer }

    private let dimLayer: CAShapeLayer = {
        let l = CAShapeLayer()
        l.fillRule = .evenOdd
        l.fillColor = UIColor.black.withAlphaComponent(0.45).cgColor
        l.strokeColor = UIColor.clear.cgColor
        l.opacity = 0.0
        return l
    }()

    private let faceLayer: CAShapeLayer = {
        let l = CAShapeLayer()
        l.strokeColor = UIColor.white.cgColor
        l.fillColor = UIColor.clear.cgColor
        l.lineWidth = 3
        l.opacity = 0.0
        l.lineJoin = .round
        l.lineCap = .round
        l.allowsEdgeAntialiasing = true
        return l
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        videoPreviewLayer.videoGravity = .resizeAspectFill
        videoPreviewLayer.addSublayer(dimLayer)
        videoPreviewLayer.addSublayer(faceLayer)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    func showFaceRect(_ normalizedRect: CGRect?) {
        CATransaction.begin(); CATransaction.setDisableActions(true)
        if let r = normalizedRect {
            let rectInLayer = videoPreviewLayer.layerRectConverted(fromMetadataOutputRect: r)
            faceLayer.path = UIBezierPath(roundedRect: rectInLayer, cornerRadius: 12).cgPath
            faceLayer.opacity = 1.0

            // dim everything except the face box
            let full = UIBezierPath(rect: bounds)
            let hole = UIBezierPath(roundedRect: rectInLayer.insetBy(dx: -4, dy: -4), cornerRadius: 14)
            full.append(hole)
            full.usesEvenOddFillRule = true
            dimLayer.path = full.cgPath
            dimLayer.opacity = 1.0
        } else {
            faceLayer.path = nil
            faceLayer.opacity = 0.0
            dimLayer.path = nil
            dimLayer.opacity = 0.0
        }
        CATransaction.commit()
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        // keep dim layer sized with view
        if let p = dimLayer.path, faceLayer.opacity > 0.0 {
            showFaceRect(videoPreviewLayer.metadataOutputRectConverted(fromLayerRect: faceLayer.path!.boundingBox))
        }
    }
}

struct CameraPreview: UIViewRepresentable {
    let session: AVCaptureSession
    let faceRect: CGRect?

    func makeUIView(context: Context) -> PreviewView {
        let v = PreviewView()
        v.videoPreviewLayer.session = session
        v.videoPreviewLayer.needsDisplayOnBoundsChange = true
        if let conn = v.videoPreviewLayer.connection {
            if #available(iOS 17.0, *) {
                if conn.isVideoRotationAngleSupported(90) { conn.videoRotationAngle = 90 }
            } else {
                conn.videoOrientation = .portrait
            }
            if conn.isVideoMirroringSupported { conn.isVideoMirrored = true }
        }
        return v
    }

    func updateUIView(_ uiView: PreviewView, context: Context) {
        uiView.showFaceRect(faceRect)
    }
}


